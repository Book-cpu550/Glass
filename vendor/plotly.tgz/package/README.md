# plotly.js-dist-min

Ready-to-use minified plotly.js distributed bundle.

Contains trace modules `bar`, `barpolar`, `box`, `candlestick`, `carpet`, `choropleth`, `choroplethmap`, `cone`, `contour`, `contourcarpet`, `densitymap`, `funnel`, `funnelarea`, `heatmap`, `histogram`, `histogram2d`, `histogram2dcontour`, `icicle`, `image`, `indicator`, `isosurface`, `mesh3d`, `ohlc`, `parcats`, `parcoords`, `pie`, `quiver`, `sankey`, `scatter`, `scatter3d`, `scattercarpet`, `scattergeo`, `scattergl`, `scattermap`, `scatterpolar`, `scatterpolargl`, `scattersmith`, `scatterternary`, `splom`, `streamtube`, `sunburst`, `surface`, `table`, `treemap`, `violin`, `volume` and `waterfall`.

For more info on plotly.js, go to https://github.com/plotly/plotly.js#readme

## Installation

```
npm install plotly.js-dist-min
```
## Usage

```js
// ES6 module
import Plotly from 'plotly.js-dist-min'

// CommonJS
var Plotly = require('plotly.js-dist-min')
```

## TypeScript

This package includes its own TypeScript declarations.

```ts
import Plotly from 'plotly.js-dist-min'
import type { Data, Layout } from 'plotly.js-dist-min'

const data: Data[] = [{ type: 'scatter', x: [1, 2, 3], y: [4, 5, 6] }]
const layout: Partial<Layout> = { title: { text: 'Demo' } }

await Plotly.newPlot(div, data, layout)
```

## Copyright and license

Code and documentation copyright 2026 Plotly, Inc.

Code released under the [MIT license](https://github.com/plotly/plotly.js/blob/main/LICENSE).

Docs released under the [Creative Commons license](https://github.com/plotly/documentation/blob/source/LICENSE).

Please visit [complete list of dependencies](https://www.npmjs.com/package/plotly.js/v/4.3.0?activeTab=dependencies).